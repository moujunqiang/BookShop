package com.example.xmfy.bookshop.net;

import android.os.AsyncTask;

import com.example.xmfy.bookshop.global.AppConstants;
import com.example.xmfy.bookshop.model.FormedData;
import com.example.xmfy.bookshop.model.User;
import com.example.xmfy.bookshop.utils.OKHttpUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import okhttp3.FormBody;

public class LoginAsyncTask extends AsyncTask<String, Void, String> {

    public AsyncResponse<User> asyncResponse;

    public void setOnAsyncResponse(AsyncResponse<User> asyncResponse)
    {
        this.asyncResponse = asyncResponse;
    }

    @Override
    protected String doInBackground(String... strings) {
        FormBody body = new FormBody.Builder()
                .add("account", strings[0])
                .add("pwd", strings[1])
                .build();
        return OKHttpUtils.doPostWithParams(AppConstants.LOGIN_ADDRESS, body);
    }

    @Override
    protected void onPostExecute(String formedString) {
        super.onPostExecute(formedString);
        Gson gson = new Gson();
        FormedData<User> formedData = gson.fromJson(formedString, new TypeToken<FormedData<User>>(){}.getType());
        asyncResponse.onDataReceivedSuccess(formedData);
    }
}
