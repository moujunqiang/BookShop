package com.example.xmfy.bookshop.global;

import android.app.Application;

import com.example.xmfy.bookshop.utils.CategoryLoader;


public class MyApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        loadCategories();
    }

    private void loadCategories() {
        CategoryLoader.loadCategories(this);
    }

}
