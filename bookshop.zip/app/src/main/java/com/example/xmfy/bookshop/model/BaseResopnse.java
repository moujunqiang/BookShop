package com.example.xmfy.bookshop.model;

public class BaseResopnse {

    /**
     * success : false
     * data : null
     * error : 请勿重复购买！
     */

    private boolean success;
    private Object data;
    private String error;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
