package com.example.xmfy.bookshop.net;

import android.os.AsyncTask;

import com.example.xmfy.bookshop.model.Carousel;
import com.example.xmfy.bookshop.model.FormedData;
import com.example.xmfy.bookshop.utils.OKHttpUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;


public class CustomedAsync extends AsyncTask<String, Void, String> {

    public AsyncResponse asyncResponse;

    public void setOnAsyncResponse(AsyncResponse asyncResponse)
    {
        this.asyncResponse = asyncResponse;
    }

    @Override
    protected String doInBackground(String... strings) {
        return OKHttpUtils.doGet(strings[0]);
    }

    @Override
    protected void onPostExecute(String msg) {
        super.onPostExecute(msg);
        if (msg != null){
            Gson gson = new Gson();
            FormedData formedData = gson.fromJson(msg, new TypeToken<FormedData<List<Carousel>>>(){}.getType());
            asyncResponse.onDataReceivedSuccess(formedData);
        }else
            asyncResponse.onDataReceivedFailed();
    }
}
