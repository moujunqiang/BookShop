package com.example.xmfy.bookshop.widget;

import android.support.design.widget.FloatingActionButton;
import android.widget.TextView;

import cn.bingoogolapple.badgeview.annotation.BGABadge;


@BGABadge({
        TextView.class,
        FloatingActionButton.class
})
public class BGABadgeInit {
}
