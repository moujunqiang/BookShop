package com.example.xmfy.bookshop.net;

import com.example.xmfy.bookshop.model.FormedData;


public interface AsyncResponse<T> {
    void onDataReceivedSuccess(FormedData<T> formedData);

    void onDataReceivedFailed();
}
