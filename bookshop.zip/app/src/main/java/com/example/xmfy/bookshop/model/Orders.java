package com.example.xmfy.bookshop.model;

public class Orders {
    private int id;
    private String buyer;
    private String seller;
    private int bookId;
    private String receiver;
    private String phone;
    private String province;
    private String city;
    private String district;
    private String location;
    private int flag;
    private String note;
    private BookInfo bookInfo;



    public Orders() {
    }

    public Orders(int id, String buyer, String seller, int bookId, String receiver, String phone, String province, String city, String district, String location, int flag, String note,BookInfo bookInfo) {
        this.id = id;
        this.buyer = buyer;
        this.seller = seller;
        this.bookId = bookId;
        this.receiver = receiver;
        this.phone = phone;
        this.province = province;
        this.city = city;
        this.district = district;
        this.location = location;
        this.flag = flag;
        this.note = note;
        this.bookInfo = bookInfo;

    }

    public BookInfo getBookInfo() {
        return bookInfo;
    }

    public void setBookInfo(BookInfo bookInfo) {
        this.bookInfo = bookInfo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Orders{" +
                "id=" + id +
                ", buyer='" + buyer + '\'' +
                ", seller='" + seller + '\'' +
                ", bookId=" + bookId +
                ", receiver='" + receiver + '\'' +
                ", phone='" + phone + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", district='" + district + '\'' +
                ", location='" + location + '\'' +
                ", flag=" + flag +
                ", note='" + note + '\'' +
                '}';
    }
}
